﻿let drivers = [];
let connection = null;

let driverIdToUpdate = -1;

getdata();
setupSignalR();


function setupSignalR() {
    connection = new signalR.HubConnectionBuilder()
        .withUrl("http://localhost:6102/hub")
        .configureLogging(signalR.LogLevel.Information)
        .build();

    connection.on("DriverCreated", (user, message) => {
        getdata();
    });

    connection.on("DriverDeleted", (user, message) => {
        getdata();
    });

    connection.on("DriverUpdated", (user, message) => {
        getdata();
    });

    connection.onclose(async () => {
        await start();
    });
    start();
}

async function start() {
    try {
        await connection.start();
        console.log("SignalR Connected.")
    } catch (err) {
        console.log(err);
        setTimeout(start, 5000);
    }
}

async function getdata() {
    await fetch('http://localhost:6102/driver')
        .then(x => x.json())
        .then(y => {
            drivers = y;

            display();
        });
}

function display() {
    document.getElementById('resultarea').innerHTML = "";
    drivers.forEach(t => {
        document.getElementById('resultarea').innerHTML +=
            "<tr><td>" + t.id + "</td><td>" + t.name +
            "</td><td>" + t.championshipId + "</td><td>" + t.teamId + "</td><td>" + `<button type="button"
            onclick="remove(${t.id})">Delete</button>` + `<button type="button"
            onclick="showupdate(${t.id})">Update</button>` + "</td></tr>";
    });
}

function remove(id) {
    fetch('http://localhost:6102/driver/' + id, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json', },
        body: null
    })
        .then(response => response)
        .then(data => {
            console.log('Success:', data);
            getdata();
        })
        .catch((error) => { console.log('Error:', error); });
}

function showupdate(id) {
    document.getElementById('drivernametoupdate').value = drivers.find(t => t['id'] == id)['name'];
    document.getElementById('driverteamidtoupdate').value = drivers.find(t => t['id'] == id)['teamId'];
    document.getElementById('driverchampionshipidtoupdate').value = drivers.find(t => t['id'] == id)['championshipId'];
    document.getElementById('updateformdiv').style.display = 'flex';
    driverIdToUpdate = id;
}

function update() {
    document.getElementById('updateformdiv').style.display = 'none';
    let Dname = document.getElementById('drivernametoupdate').value;
    let DteamId = document.getElementById('driverteamidtoupdate').value;
    let DchampionshipId = document.getElementById('driverchampionshipidtoupdate').value;
    fetch('http://localhost:6102/driver', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', },
        body: JSON.stringify(
            { name: Dname, teamId: DteamId, ChampionshipId: DchampionshipId, id: driverIdToUpdate })
    })
        .then(response => response)
        .then(data => {
            console.log('Success:', data);
            getdata();
        })
        .catch((error) => { console.log('Error:', error); });
}

function create() {
    let Dname = document.getElementById('drivername').value;
    let DteamId = document.getElementById('driverteamid').value;
    let DchampionshipId = document.getElementById('driverid').value;
    fetch('http://localhost:6102/driver', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', },
        body: JSON.stringify(
            { name: Dname, teamId: DteamId, ChampionshipId: DchampionshipId })
    })
        .then(response => response)
        .then(data => {
            console.log('Success:', data);
            getdata();
        })
        .catch((error) => { console.log('Error:', error); });
}