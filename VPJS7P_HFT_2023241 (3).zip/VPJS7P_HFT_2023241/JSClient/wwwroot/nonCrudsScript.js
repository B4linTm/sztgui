﻿let AgeAvarage = 0;
let Shiftwithrighthand = [];
let HasOwnMotor = [];
let HasFineAfterRuleBreak = "";

getData();


async function getData() {
    let url1 = "http://localhost:6102/championship/avg";
    let response1 = await fetch(url1);
    let data1 = await response1.json();

    AgeAvarage = data1;


    let url2 = "http://localhost:6102/driver/shiftrighthand";
    let response2 = await fetch(url2);
    let data2 = await response2.json();

    Shiftwithrighthand = data2;


    let url3 = "http://localhost:6102/Championship/hasownmotor";
    let response3 = await fetch(url3);
    let data3 = await response3.json();
    HasOwnMotor = data3;


    let url4 = "http://localhost:6102/Championship/hasfineafterrulebreak";
    let response4 = await fetch(url4);
    let data4 = await response4.text();
    HasFineAfterRuleBreak = data4;


    


    display1();
    display2();
    display3();
    display4();
    


}

function display1() {
    document.querySelector("#ageAvarage").innerHTML += "<ul><li>" + AgeAvarage + "</li>";
    document.querySelector("#ageAvarage").innerHTML += "</ul>";
}

function display2() {
    document.querySelector("#shiftwithrighthand").innerHTML += "<ul>";
    Shiftwithrighthand.forEach(t => {
        document.querySelector("#shiftwithrighthand").innerHTML += "<li>" + t + "</li>";
    })
    document.querySelector("#shiftwithrighthand").innerHTML += "</ul>";
}

function display3() {
    document.querySelector("#HasOwnMotor").innerHTML += "<ul>";
    HasOwnMotor.forEach(t => {
        document.querySelector("#HasOwnMotor").innerHTML += "<li>" + t.name + "</li>";
    })
    document.querySelector("#HasOwnMotor").innerHTML += "</ul>";
}

function display4() {
    document.querySelector("#HasFineAfterRuleBreak").innerHTML += "<ul><li> " + t + "</li>";
    document.querySelector("#HasFineAfterRuleBreak").innerHTML += "</ul>";
}


