﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VPJS7P_HFT_2023241.Models;

namespace VPJS7P_HFT_2023241.Logic
{
    public interface ITeamLogic
    {

        void Create(Team item);
        void Delete(int id);
        double AvarageSalaryInTeam(int teamId);
        Team Read(int id);
        IEnumerable<Team> ReadAll();
        void Update(Team item);
    }
}
