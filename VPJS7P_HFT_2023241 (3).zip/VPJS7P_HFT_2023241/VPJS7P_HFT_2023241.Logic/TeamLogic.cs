﻿using System;
using System.Collections.Generic;
using System.Linq;
using VPJS7P_HFT_2023241.Models;
using VPJS7P_HFT_2023241.Repository;

namespace VPJS7P_HFT_2023241.Logic
{
    public class TeamLogic : ITeamLogic
    {
        IRepository<Team> repo;

        public TeamLogic(IRepository<Team> repo)
        {
            this.repo = repo;
        }

        public double AvarageSalaryInTeam(int teamId)
        {


            var avg = (from team in this.repo.ReadAll()
                       where team.Id == teamId
                       select team.Drivers.Select(x => x.Salary)).FirstOrDefault().Average();


            return avg;


        }

        public void Create(Team item)
        {
            if (item.Id < 0)
            {
                throw new ArgumentException("The id must be higher than 0");
            }
            else
            {
                this.repo.Create(item);
            }
        }

        public void Delete(int id)
        {
            this.repo.Delete(id);
        }

        public Team Read(int id)
        {
            if (this.repo.Read(id) == null)
            {
                throw new ArgumentException("The team does not exists");
            }
            return this.repo.Read(id);
        }

        public IEnumerable<Team> ReadAll()
        {
            return this.repo.ReadAll();
        }

        public void Update(Team item)
        {
            this.repo.Update(item);
        }
    }
}
