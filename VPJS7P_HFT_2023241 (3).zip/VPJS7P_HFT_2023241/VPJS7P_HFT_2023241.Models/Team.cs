﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace VPJS7P_HFT_2023241.Models
{
    public class Team
    {
        

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string Name { get; set; }
        [ForeignKey(nameof(Championship))]
        public int ChampionshipId { get; set; }
        public bool HasOwnMotor { get; set; }
        [NotMapped]
        [JsonIgnore]
        public virtual Championship Championship { get; set;}
        [NotMapped]
        [JsonIgnore]
        public virtual ICollection<Driver> Drivers { get; set; }

        public Team()
        {

        }

        public Team(int id, string name, int championshipId, bool hasOwnMotor)
        {
            Id = id;
            Name = name;
            ChampionshipId = championshipId;
            HasOwnMotor = hasOwnMotor;
        }


    }
}
