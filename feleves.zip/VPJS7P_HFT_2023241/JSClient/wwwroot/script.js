﻿let championships = [];
let connection = null;

let chIdToUpdate = -1;

getdata();
setupSignalR();


function setupSignalR() {
    connection = new signalR.HubConnectionBuilder()
        .withUrl("http://localhost:6102/hub")
        .configureLogging(signalR.LogLevel.Information)
        .build();

    connection.on("ChampionshipCreated", (user, message) => {
        getdata();
    });

    connection.on("ChampionshipDeleted", (user, message) => {
        getdata();
    });

    connection.on("ChampionshipUpdated", (user, message) => {
        getdata();
    });

    connection.onclose(async () => {
        await start();
    });
    start();
}

async function start() {
    try {
        await connection.start();
        console.log("SignalR Connected.")
    } catch (err) {
        console.log(err);
        setTimeout(start, 5000);
    }
}

async function getdata() {
    await fetch('http://localhost:6102/championship')
        .then(x => x.json())
        .then(y => {
            championships = y;

            display();
        });
}

function display() {
    document.getElementById('resultarea').innerHTML = "";
    championships.forEach(t => {
        document.getElementById('resultarea').innerHTML +=
            "<tr><td>" + t.id + "</td><td>" + t.name +
            "</td><td>" + `<button type="button"
            onclick="remove(${t.id})">Delete</button>` + `<button type="button"
            onclick="showupdate(${t.id})">Update</button>` + "</td></tr>";
    });
}

function remove(id) {
    fetch('http://localhost:6102/championship/' + id, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json', },
        body: null
    })
        .then(response => response)
        .then(data => {
            console.log('Success:', data);
            getdata();
        })
        .catch((error) => { console.log('Error:', error); });
}

function showupdate(id) {
    let intId = parseInt(id); // hozzáadva
    document.getElementById('championshiptoupdate').value = championships.find(t => t.id === intId)['name']; // módosítva

    document.getElementById('updateformdiv').style.display = 'flex';
    chIdToUpdate = intId; // módosítva
}

function update() {
    document.getElementById('updateformdiv').style.display = 'none';
    let Cname = document.getElementById('championshiptoupdate').value;

    fetch('http://localhost:6102/championship', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', },
        body: JSON.stringify(
            { name: Cname, id: chIdToUpdate })
    })
        .then(response => response)
        .then(data => {
            console.log('Success:', data);
            getdata();
        })
        .catch((error) => { console.log('Error:', error); });
}

function create() {
    let Oname = document.getElementById('championshipname').value;

    fetch('http://localhost:6102/championship', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', },
        body: JSON.stringify(
            { name: Oname }) // itt változtattam
    })
        .then(response => response.json()) // változtattam
        .then(data => {
            console.log('Success:', data);
            getdata();
        })
        .catch((error) => { console.log('Error:', error); });
}