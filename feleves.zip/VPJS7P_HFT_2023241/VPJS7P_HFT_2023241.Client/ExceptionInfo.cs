﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VPJS7P_HFT_2023241.Client
{
    public class ExceptionInfo
    {
        public ExceptionInfo()
        {

        }

        public string Message {  get; set; }
    }
}
