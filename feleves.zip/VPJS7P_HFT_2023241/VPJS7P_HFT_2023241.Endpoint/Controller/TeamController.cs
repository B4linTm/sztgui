﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using VPJS7P_HFT_2023241.Endpoint.Services;
using VPJS7P_HFT_2023241.Logic;
using VPJS7P_HFT_2023241.Models;

namespace VPJS7P_HFT_2023241.Endpoint.Controller
{
    [Route("[controller]")]
    [ApiController]
    public class TeamController : ControllerBase
    {
        ITeamLogic teamlogic;
        IHubContext<SignalRHub> hub;

        public TeamController(ITeamLogic teamlogic, IHubContext<SignalRHub> hub)
        {
            this.teamlogic = teamlogic;
            this.hub = hub;
        }

        

        [HttpGet]
        public IEnumerable<Team> ReadAll()
        {
            return this.teamlogic.ReadAll();
        }

        [HttpGet("{id}")]
        public Team Read(int id)
        {
            return this.teamlogic.Read(id);
        }

        [HttpPost]
        public void Create([FromBody] Team value)
        {
            this.teamlogic.Create(value);
            this.hub.Clients.All.SendAsync("TeamCreated", value);
        }

        [HttpPut]
        public void Update([FromBody] Team value)
        {
            this.teamlogic.Update(value);
            this.hub.Clients.All.SendAsync("TeamUpdated", value);
        }

        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            var teamtodelete = this.teamlogic.Read(id);
            this.teamlogic.Delete(id);
            this.hub.Clients.All.SendAsync("TeamDeleted", teamtodelete);
        }
    }
}
