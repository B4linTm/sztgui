﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VPJS7P_HFT_2023241.Models;
using VPJS7P_HFT_2023241.Repository;

namespace VPJS7P_HFT_2023241.Logic
{
    public class DriverLogic : IDriverLogic
    {
        IRepository<Driver> repo;

        public DriverLogic(IRepository<Driver> repo)
        {
            this.repo = repo;
        }

        public void Create(Driver item)
        {
            if (item.Id < 0)
            {
                throw new ArgumentException("The Id must be higher than 0");
            }
            else
            {
                this.repo.Create(item);
            }
        }
        public Driver Read(int id)
        {
            if (this.repo.Read(id) == null)
            {
                throw new ArgumentException("The Driver does not exists");
            }
            return this.repo.Read(id);
        }

        public void Delete(int id)
        {
            this.repo.Delete(id);
        }
        public IEnumerable<Driver> ReadAll()
        {
            return this.repo.ReadAll();
        }

        public void Update(Driver item)
        {
            this.repo.Update(item);
        }

        public IEnumerable<Driver> GetDriversOlderthanparameter(int age)
        {
              

            return repo.ReadAll().Where(x => x.Age > age);

        }

        public int GetOldestDriver()
        {
            return repo.ReadAll().OrderByDescending(x => x.Age).First().Age;
                         
        }

        public int GetYoungestDriver()
        {
            var youngest = repo.ReadAll().OrderBy(x => x.Age).First().Age;

            return youngest;
        }

        

        
    }
}
