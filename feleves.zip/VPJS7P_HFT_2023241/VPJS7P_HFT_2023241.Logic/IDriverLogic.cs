﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VPJS7P_HFT_2023241.Models;

namespace VPJS7P_HFT_2023241.Logic
{
    public interface IDriverLogic
    {
        void Create(Driver item);
        void Delete(int id);
        IEnumerable<Driver> GetDriversOlderthanparameter(int age);
        int GetOldestDriver();
        int GetYoungestDriver();
        Driver Read(int id);

        IEnumerable<Driver> ReadAll();

        void Update(Driver item);

    }
}
