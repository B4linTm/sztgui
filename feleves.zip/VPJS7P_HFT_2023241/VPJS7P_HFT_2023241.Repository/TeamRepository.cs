﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VPJS7P_HFT_2023241.Models;

namespace VPJS7P_HFT_2023241.Repository
{
    public class TeamRepository : Repository<Team>, IRepository<Team>
    {
        public TeamRepository(FormaDbContext context) : base(context)
        {
                
        }
        public override Team Read(int id)
        {
            return this.Context.Teams.First(x => x.Id == id);
        }

        public override void Update(Team item)
        {
            var Older = Read(item.Id);
            foreach (var prop in Older.GetType().GetProperties())
            {
                if (prop.GetAccessors().FirstOrDefault(t => t.IsVirtual) == null)
                {
                    prop.SetValue(Older, prop.GetValue(item));
                }

            }
            Context.SaveChanges();
        }
    }
}
