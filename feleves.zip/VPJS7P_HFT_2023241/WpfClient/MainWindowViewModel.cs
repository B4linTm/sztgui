﻿using Microsoft.Toolkit.Mvvm.ComponentModel;
using Microsoft.Toolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using VPJS7P_HFT_2023241.Models;

namespace WpfClient
{
    class MainWindowViewModel : ObservableRecipient
    {
        public RCollection<Team> Teams { get; set; }
        public RCollection<Driver> Drivers { get; set; }
        public RCollection<Championship> Championships { get; set; }

        public string AvgAge { get; set; }
        public List<string> OlderThan30 { get; set; }
        public List<Driver> GetTeamDrivers { get; set; }
        public string GetDriversTeam { get; set; }
        public List<HasOwnMotorInfo> Teamsownsmotor { get; set; }

        public ICommand CreateTeamCommand { get; set; }
        public ICommand DeleteTeamCommand { get; set; }
        public ICommand UpdateTeamCommand { get; set; }

        public ICommand CreateDriverCommand { get; set; }
        public ICommand DeleteDriverCommand { get; set; }
        public ICommand UpdateDriverCommand { get; set; }

        public ICommand CreateChampionshipCommand { get; set; }
        public ICommand DeleteChampionshipCommand { get; set; }
        public ICommand UpdateChampionshipCommand { get; set; }


        private Team selectedTeam;

        public Team SelectedTeam
        {
            get { return selectedTeam; }
            set
            {
                if(value != null)
                {
                    selectedTeam = new Team()
                    {
                        Id = value.Id,
                        Name = value.Name,
                        ChampionshipId = value.ChampionshipId,
                        HasOwnMotor = value.HasOwnMotor,
                        Championship = value.Championship,
                        Drivers = value.Drivers,
                    };
                    OnPropertyChanged();
                    (DeleteTeamCommand as RelayCommand).NotifyCanExecuteChanged();
                }
            }
        }

    }
}
